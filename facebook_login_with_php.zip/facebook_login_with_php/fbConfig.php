<?php
if(!session_id()){
    session_start();
}

// Include the autoloader provided in the SDK
include_once 'src/autoload.php';

// Include required libraries
include_once 'src/FacebookClient.php';
include_once 'src/Authentication/OAuth2Client.php';
include_once 'src/Facebook.php';
use src\Exceptions\FacebookResponseException;
use src\Exceptions\FacebookSDKException;

/*
 * Configuration and setup Facebook SDK
 */
$appId         = '188395511755285'; //Facebook App ID
$appSecret     = 'ab6b80b18ff8d4bf994724247ebcf5fc'; //Facebook App Secret
$redirectURL   = 'http://localhost/facebook_login_with_php/'; //Callback URL
$fbPermissions = array('email');  //Optional permissions

$fb = new Facebook(array(
    'app_id' => $appId,
    'app_secret' => $appSecret,
    'default_graph_version' => 'v2.2',
));

// Get redirect login helper
$helper = $fb->getRedirectLoginHelper();

// Try to get access token
try {
    if(isset($_SESSION['facebook_access_token'])){
        $accessToken = $_SESSION['facebook_access_token'];
    }else{
          $accessToken = $helper->getAccessToken();
    }
} catch(FacebookResponseException $e) {
     echo 'Graph returned an error: ' . $e->getMessage();
      exit;
} catch(FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
      exit;
}

?>